package Login;

import People.Employee;
import java.util.*;

public class Login {    
    public boolean verifyloginUser(String userName, String passwordData, List<Employee> list){
        if (list.stream().anyMatch((m) -> (m.getName().equals(userName) && m.getPassword().equals(passwordData)))) {
            return true;
        }  
        return false;
    }  
     public Employee getObj(String userName, String passwordData, List<Employee> list){
        for (Employee m : list){
            if (m.getName().equals(userName) && m.getPassword().equals(passwordData))
                return m;  
        }  
        return null;
    }
}
