package Login;

import People.Employee;
import People.Manager;
import DAO.ManagerDAO;
import java.util.*;

public class Login {

    public boolean verifyloginUser(String userName, String passwordData, List<Employee> list) {
        if (list.stream().anyMatch((m) -> (m.getName().equals(userName) && m.getPassword().equals(passwordData)))) {
            return true;
        }
        return false;
    }

    public Employee getObj(String userName, String passwordData, List<Employee> list) {
        for (Employee m : list) {
            if (m.getName().equals(userName) && m.getPassword().equals(passwordData)) {
                return m;
            }
        }
        return null;
    }

    public void verifyFirstUser(List<Employee> list) {
        if (list.isEmpty()) {
            ManagerDAO mDAO = new ManagerDAO();
            mDAO.Create(new Manager(1, "adm", "adm"));
        }
    }
}
