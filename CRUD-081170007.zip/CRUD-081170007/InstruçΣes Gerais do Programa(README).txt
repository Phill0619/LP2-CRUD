-o crud main se encontra no caminho:
	LPCRUD/src/lpcrud
-o programa come�a com o LOGIN;
-h� um usu�rio padr�o de nome: "adm" e senha: "adm" sendo um "manager";
-ao fazer o login, ele avan�a para o HOME MENU onde � poss�vel criar outros usu�rios;
-cada novo registro � adicionado no arquivo txt referente ao seu tipo:
	product, order -> things
	manager, vendor, client -> people
- os arquivos txt se encontra no caminho:
	LPCRUD/src/DBTXT/DatabaseThingTXT ou DatabasePeopleTXT na mesma pasta;
-