package Things;

public abstract class Thing {
    
    protected int Id;
    protected String Type;
    
    public abstract void setId(int Id);
    public abstract int getId();
    public abstract void setType(String Type);
    public abstract String getType();
}
