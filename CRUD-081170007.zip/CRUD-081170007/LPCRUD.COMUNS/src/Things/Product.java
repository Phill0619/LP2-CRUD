package Things;

public final class Product extends Thing {

    //private int Id;
    private String Name;
    private int Price;

    public Product(int Id, String Name, int Price) {
        setId(Id);
        setName(Name);
        setPrice(Price);
        setType("Product");
    }

    @Override
    public void setId(int Id) {
        this.Id = Id;
    }

    @Override
    public int getId() {
        return Id;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getName() {
        return Name;
    }

    public void setPrice(int Price) {
        this.Price = Price;
    }

    public int getPrice() {
        return Price;
    }

    @Override
    public void setType(String Type) {
        this.Type = Type;
    }

    @Override
    public String getType() {
        return Type;
    }
}
