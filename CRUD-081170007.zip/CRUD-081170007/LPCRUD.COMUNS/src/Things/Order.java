package Things;

public class Order extends Thing{   
    //private int Id;
    private int ClientId;
    //private Product[] Products;
    
    public Order(int Id, int ClientId){//,int size){
        setId(Id);
        setClientId(ClientId);
        setType("Order");
        //Products = new Product[size];
    }
    
    public void setClientId(int ClientId) {
      this.ClientId = ClientId;
    }
    public int getClientId() {
       return ClientId;
    }
    @Override
    public void setId(int Id) {
      this.Id = Id;
    }
    @Override
    public int getId() {
       return Id;
    }
    /*
    public void addProductId(Product p) {
        Products[Products.length] = p; 
    }
    public Product[] getProducts() {    
        return Products;
    }
    public void removeProductById(int p){
        
       Product[] vetor = new Product[Products.length - 1];
       int cont = 0;
        for (Product n : Products)
        {
            if (n.getId() != p)
                vetor[cont] = n;
            cont++;
        }
        Products = vetor;
    }
    public int getOrderTotalPrice(){
        int totalvalue = 0;
        for (int i = 0; i < Products.length; i++) {
            totalvalue += Products[i].getPrice();
        }
        return totalvalue;
    }
    /*
    public void CancelOrder(){
        Products = new Product[0];
    }*/
    
    @Override
    public void setType(String Type) {
        this.Type = Type;
    }

    @Override
    public String getType() {
        return Type;
    }
}
