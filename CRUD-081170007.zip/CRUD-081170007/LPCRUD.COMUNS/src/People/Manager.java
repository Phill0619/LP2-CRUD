package People;

public final class Manager extends Employee {

    public Manager(int Id, String Name, String Password) {
        setId(Id);
        setName(Name);
        setPassword(Password);
        setType("Manager");
    }

    @Override
    public void setId(int Id) {
        this.Id = Id;
    }

    @Override
    public int getId() {
        return Id;
    }

    @Override
    public void setName(String Name) {
        this.Name = Name;
    }

    @Override
    public String getName() {
        return Name;
    }

    @Override
    public void setPassword(String Password) {
        this.Password = Password;
    }

    @Override
    public String getPassword() {
        return Password;
    }

    @Override
    public void setType(String Type) {
        this.Type = Type;
    }

    @Override
    public String getType() {
        return Type;
    }
}
