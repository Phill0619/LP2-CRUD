package People;

public abstract class Employee extends Person { 
    
    public String Password;
   
    public abstract String getPassword();
    public abstract void setPassword(String Password);
}
