package People;

public class Client extends Person {

    public Client(int Id, String Name) {
        setId(Id);
        setName(Name);
        setType("Client");
    }

    @Override
    public void setId(int Id) {
        this.Id = Id;
    }

    @Override
    public int getId() {
        return Id;
    }

    @Override
    public void setName(String Name) {
        this.Name = Name;
    }

    @Override
    public String getName() {
        return Name;
    }

    @Override
    public void setType(String Type) {
        this.Type = Type;
    }

    @Override
    public String getType() {
        return Type;
    }

}
