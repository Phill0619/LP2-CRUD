package People;

public abstract class Person {
    
    protected int Id;
    protected String Name;  
    protected String Type;
    
    public abstract void setId(int Id);
    public abstract int getId();
    public abstract void setName(String Name);
    public abstract String getName();
    public abstract void setType(String Type);
    public abstract String getType();
}