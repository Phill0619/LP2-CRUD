package DAO;

import People.Employee;
import People.Person;
import People.Manager;
import People.Vendor;
import People.Client;
import Things.Order;
import Things.Product;
import Things.Thing;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import org.json.JSONObject;

public abstract class MainDAO {

    protected String databasePathPeople = System.getProperty("user.dir") + "\\src\\DBTXT\\DatabasePeopleTXT.txt";
    protected String databasePathThing = System.getProperty("user.dir") + "\\src\\DBTXT\\DatabaseThingTXT.txt";

    public abstract void Create(Person o);
    public abstract void Create(Thing t);

    public abstract Object Read();

    public abstract void Update(Object o);

    public abstract void Delete(Object o);

    public List<Person> returnPeople() {
        String st;
        //List<Person> list = new LinkedList<Person>();
        List<Person> list = new LinkedList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(databasePathPeople))) {
            while ((st = br.readLine()) != null) {
                JSONObject j = new JSONObject(st);
                
                switch (j.getString("type")) {
                    case "Manager": {
                        Manager m = new Manager(j.getInt("id"), j.getString("name"), j.getString("password"));
                        list.add(m);
                        break;
                    }
                    case "Vendor": {
                        Vendor m = new Vendor(j.getInt("id"), j.getString("name"), j.getString("password"));
                        list.add(m);
                        break;
                    }
                    case "Client": {
                        Client m = new Client(j.getInt("id"), j.getString("name"));
                        list.add(m);
                        break;
                    }
                    default:
                        break;
                }
            }
        } catch (IOException e) {
            System.out.print(e.toString());
        }
        return list;
    }
    public List<Thing> returnThing() {
        String st;
        //List<Person> list = new LinkedList<Person>();
        List<Thing> list = new LinkedList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(databasePathThing))) {
            while ((st = br.readLine()) != null) {
                JSONObject j = new JSONObject(st);
                
                switch (j.getString("type")) {
                    case "Product": {
                        Product p = new Product(j.getInt("id"), j.getString("name"), j.getInt("price"));
                        list.add(p);
                        break;
                    }
                    case "Order": {
                        Order o = new Order(j.getInt("id"), j.getInt("clientid"));//j.getProducts()("products"));
                        list.add(o);
                        break;
                    }
                    default:
                        break;
                }
            }
        } catch (IOException e) {
            System.out.print(e.toString());
        }
        return list;
    }
}
