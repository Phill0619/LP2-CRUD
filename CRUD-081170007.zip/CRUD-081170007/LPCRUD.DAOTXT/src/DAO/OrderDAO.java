package DAO;

import People.Employee;
import People.Person;
import People.Manager;
import Things.Order;
import Things.Product;
import Things.Thing;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import org.json.JSONObject;

public class OrderDAO extends MainDAO {

    @Override
    public void Create(Person o) {
        //       
    }

    @Override
    public void Create(Thing o) {
        List<Thing> fulllist = new LinkedList<>();
        fulllist = returnThing();
        fulllist.add(o);

        try (FileWriter file = new FileWriter(databasePathThing)) {
            for (Thing t : fulllist) {
                file.append(new JSONObject(t).toString() + "\n");
            }
        } catch (IOException e) {
            System.out.print(e.toString());
        }
    }

    @Override
    public List<Thing> Read() {
        String st;
        List<Thing> list = new LinkedList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(databasePathThing))) {
            while ((st = br.readLine()) != null) {
                JSONObject j = new JSONObject(st);
                if (j.getString("type").equals("Product")) {
                    Order or = new Order(j.getInt("id"), j.getInt("clientid"));//, j.getInt("price"));
                    list.add(or);
                }
            }
        } catch (IOException e) {
            System.out.print(e.toString());
        }
        return list;
    }

    @Override
    public void Update(Object o) {

    }

    @Override
    public void Delete(Object o) {

    }

}
