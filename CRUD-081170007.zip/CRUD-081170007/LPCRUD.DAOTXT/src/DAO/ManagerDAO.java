package DAO;

import People.Manager;
import People.Employee;
import People.Person;
import People.Vendor;
import Things.Thing;
import java.io.BufferedReader;
import org.json.JSONObject;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileReader;
import java.util.*;

public class ManagerDAO extends EmployeeDAO {

    @Override
    public void Create(Person o) {

        List<Person> fulllist = returnPeople();
        fulllist.add(o);

        try (FileWriter file = new FileWriter(databasePathPeople)) {
            for (Person m : fulllist) {
                file.append(new JSONObject(m).toString() + "\n");
            }
        } catch (IOException e) {
            System.out.print(e.toString());
        }
    }

    @Override
    public List<Employee> Read() {
        String st;
        List<Employee> list = new LinkedList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(databasePathPeople))) {
            while ((st = br.readLine()) != null) {
                JSONObject j = new JSONObject(st);
                if (j.getString("type").equals("Manager")) {
                    Manager m = new Manager(j.getInt("id"), j.getString("name"), j.getString("password"));
                    list.add(m);
                }
            }
        } catch (IOException e) {
            System.out.print(e.toString());
        }
        return list;
    }

    @Override
    public void Update(Object o) {

    }

    @Override
    public void Delete(Object o) {

    }

    public List<Employee> returnEmployee() {
        String st;
        List<Employee> list = new LinkedList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(databasePathPeople))) {
            while ((st = br.readLine()) != null) {
                JSONObject j = new JSONObject(st);
                if (j.getString("type").equals("Manager")) {
                    Manager m = new Manager(j.getInt("id"), j.getString("name"), j.getString("password"));
                    list.add(m);
                } else if (j.getString("type").equals("Vendor")) {
                    Vendor m = new Vendor(j.getInt("id"), j.getString("name"), j.getString("password"));
                    list.add(m);
                }
            }
        } catch (IOException e) {
            System.out.print(e.toString());
        }
        return list;
    }

    @Override
    public void Create(Thing t) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
