package DAO;

public abstract class EmployeeDAO extends MainDAO {    
  
}
