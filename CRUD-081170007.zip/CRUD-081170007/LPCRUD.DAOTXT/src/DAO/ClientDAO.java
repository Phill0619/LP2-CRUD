package DAO;

import People.Employee;
import People.Person;
import People.Manager;
import People.Client;
import Things.Thing;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import org.json.JSONObject;

public class ClientDAO extends MainDAO{
       
    @Override
    public void Create(Person o){       
     
        List<Person> fulllist = new LinkedList<>();
        fulllist = returnPeople();
        fulllist.add(o);
        
        try (FileWriter file = new FileWriter(databasePathPeople)) {            
            for(Person m: fulllist)
            file.append(new JSONObject(m).toString() + "\n");       
        } 
        catch (IOException e) {
            System.out.print(e.toString());
        }
    }
    @Override
    public List<Person> Read(){ 
        
        String st;
        List<Person> list = new LinkedList<Person>();        
        try (BufferedReader br = new BufferedReader(new FileReader(databasePathPeople))){
            while ((st = br.readLine()) != null) {                      
               JSONObject j = new JSONObject(st);
               if(j.getString("type").equals("Client")){   
                   Client m = new Client(j.getInt("id"),j.getString("name"));
                   list.add(m);
               }
            }            
        }
        catch(IOException e) {
            System.out.print(e.toString());
        }
        return list;
    }
    @Override
    public void Update(Object o){
        
    }
    @Override
    public void Delete(Object o){
        
    }

    @Override
    public void Create(Thing t) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
