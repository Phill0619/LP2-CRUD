/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import People.Person;
import Things.Product;
import Things.Thing;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import org.json.JSONObject;

/**
 *
 * @author NIKON-IMPRESSORA
 */
public class ProductDAO extends MainDAO {

    public void Create(Thing o) {

        List<Thing> fulllist = new LinkedList<>();
        fulllist = returnThing();
        fulllist.add(o);

        try (FileWriter file = new FileWriter(databasePathThing)) {
            for (Thing t : fulllist) {
                file.append(new JSONObject(t).toString() + "\n");
            }
        } catch (IOException e) {
            System.out.print(e.toString());
        }
    }

    @Override
    public List<Thing> Read() {

        String st;
        List<Thing> list = new LinkedList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(databasePathThing))) {
            while ((st = br.readLine()) != null) {
                JSONObject j = new JSONObject(st);
                if (j.getString("type").equals("Product")) {
                    Product p = new Product(j.getInt("id"), j.getString("name"), j.getInt("price"));
                    list.add(p);
                }
            }
        } catch (IOException e) {
            System.out.print(e.toString());
        }
        return list;
    }

    @Override
    public void Update(Object o) {

    }

    @Override
    public void Delete(Object o) {

    }

    @Override
    public void Create(Person o) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
