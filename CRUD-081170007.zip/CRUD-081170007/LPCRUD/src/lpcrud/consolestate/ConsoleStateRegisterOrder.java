/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lpcrud.consolestate;

import DAO.OrderDAO;
import DAO.ProductDAO;
import People.Employee;
import Things.Order;
import Things.Product;
import java.util.Scanner;
import lpcrud.LPCRUD;

/**
 *
 * @author NIKON-IMPRESSORA
 */
public class ConsoleStateRegisterOrder extends ConsoleState {
    
    @Override
    public boolean Execute(Employee e) {
        
        Scanner scan = new Scanner(System.in);
        System.out.println("---------------------------------");
        System.out.println("------ Registering a Order ------");  
        
        try{
            System.out.println("Id"); 
            int id = scan.nextInt();
            System.out.println("Client Id");
            int clientid = scan.nextInt();
            
            Order or = new Order(id,clientid);
            OrderDAO oDAO = new OrderDAO();
            oDAO.Create(or);
        }
        catch(Exception d){
            System.out.print(d.toString());
        }
        
        System.out.println("Order registred!");        
        LPCRUD.consoleState = EnumConsoleStates.HOMEMENU.getEstadoMaquina();  
        return false;
    }
    
}
