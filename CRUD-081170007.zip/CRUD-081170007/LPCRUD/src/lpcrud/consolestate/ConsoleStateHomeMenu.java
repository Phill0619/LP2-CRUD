/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lpcrud.consolestate;

import People.Employee;
import java.util.Scanner;
import lpcrud.LPCRUD;

/**
 *
 * @author NIKON-IMPRESSORA
 */
public class ConsoleStateHomeMenu extends ConsoleState {

    @Override
    public boolean Execute(Employee e) {
        System.out.println("-----------------------");
        System.out.println("------ Home Menu ------");
        System.out.println("Id: " + e.getId() + " Name: " + e.getName() + "\n Function: " + e.getType());
        System.out.println("1 - Create");
        System.out.println("2 - Read");
        System.out.println("3 - Update");
        System.out.println("4 - Delete");
        System.out.println("0 - Exit");
        Scanner scan = new Scanner(System.in);
        int opcao = scan.nextInt();
        switch (opcao) {
            case 0:
                return true;
            case 1: {
                if (e.getType().equals("Manager")) {
                    LPCRUD.consoleState = EnumConsoleStates.CREATEMENUMANAGER.getEstadoMaquina();
                } else {
                    LPCRUD.consoleState = EnumConsoleStates.CREATEMENUVENDOR.getEstadoMaquina();
                }
            }
            break;
            case 2:
                LPCRUD.consoleState = EnumConsoleStates.READMENUEMPLOYEE.getEstadoMaquina();
                break;
            case 3:
                break;
            case 4:
                break;

        }
        return false;
    }
}
