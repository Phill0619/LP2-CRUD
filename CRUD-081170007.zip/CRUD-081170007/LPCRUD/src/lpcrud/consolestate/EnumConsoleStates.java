package lpcrud.consolestate;

public enum EnumConsoleStates {
    
    HOMEMENU(new ConsoleStateHomeMenu()),
    CREATEMENUMANAGER(new ConsoleStateCreateMenuManager()),
    CREATEMENUVENDOR(new ConsoleStateCreateMenuVendor()),     
    REGISTERMANAGER(new ConsoleStateRegisterManager()), 
    REGISTERVENDOR(new ConsoleStateRegisterVendor()),
    REGISTERCLIENT(new ConsoleStateRegisterClient()),
    REGISTERPRODUCT(new ConsoleStateRegisterProduct()),
    REGISTERORDER(new ConsoleStateRegisterOrder()),
    READMENUEMPLOYEE(new ConsoleStateReadMenuEmployee()),
    ; 
    
    private final ConsoleState estadoMaquina;
    
    EnumConsoleStates(ConsoleState estadoMaquina) {
        this.estadoMaquina = estadoMaquina;
    } 
    
    public ConsoleState getEstadoMaquina() {
        return estadoMaquina;
    }
}
