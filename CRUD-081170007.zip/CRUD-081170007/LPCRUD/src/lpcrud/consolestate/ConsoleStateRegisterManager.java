/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lpcrud.consolestate;

import DAO.ManagerDAO;
import People.Employee;
import People.Manager;
import java.util.Scanner;
import lpcrud.LPCRUD;

/**
 *
 * @author NIKON-IMPRESSORA
 */
public class ConsoleStateRegisterManager extends ConsoleState {
    
    @Override
    public boolean Execute(Employee e) {
        
        Scanner scan = new Scanner(System.in);
        System.out.println("-----------------------------------");
        System.out.println("------ Registering a Manager ------");  
        
        try{
            System.out.println("Id"); 
            int id = scan.nextInt();
            System.out.println("Name");
            String name = scan.next();
            System.out.println("Password");
            String password = scan.next();
            
            Manager m = new Manager(id,name,password);
            ManagerDAO managerDAO = new ManagerDAO();
            managerDAO.Create(m);            
        }
        catch(Exception d){
            System.out.print(d.toString());
        }
        
        System.out.println("Manager created!");        
        LPCRUD.consoleState = EnumConsoleStates.HOMEMENU.getEstadoMaquina();  
        return false;
    }
}
