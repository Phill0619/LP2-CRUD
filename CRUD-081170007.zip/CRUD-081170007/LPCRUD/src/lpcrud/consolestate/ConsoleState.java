package lpcrud.consolestate;

import People.Employee;

public abstract class ConsoleState {

    public abstract boolean Execute(Employee e);
    
}
