package lpcrud.consolestate;

import lpcrud.LPCRUD;
import Login.Login;
import java.util.Scanner;
import DAO.ManagerDAO;
import People.Employee;

public class ConsoleStateLogin {

    public Employee ExecuteLogin() {
        Boolean Logado = false;
        do
        {
            Scanner scan = new Scanner(System.in);
            System.out.println("-------------------");
            System.out.println("------ Login ------");
            System.out.println("Name: ");
            String name = scan.next();
            System.out.println("Password");
            String password = scan.next();

            Login l = new Login();
            ManagerDAO m = new ManagerDAO();

            if (l.verifyloginUser(name, password, m.returnEmployee())) {
                LPCRUD.consoleState = EnumConsoleStates.HOMEMENU.getEstadoMaquina();
                return l.getObj(name, password, m.returnEmployee());
            }
        }while (!Logado);
        return null;
    }
}
