package lpcrud.consolestate;

import lpcrud.LPCRUD;
import Login.Login;
import java.util.Scanner;
import DAO.ManagerDAO;
import People.Employee;
import People.Manager;
import java.util.List;

public class ConsoleStateLogin {

    public Employee ExecuteLogin() {
        Boolean Logado = false;
        do
        {
            
            verifyFirstUser(new ManagerDAO().returnEmployee());
        
            Scanner scan = new Scanner(System.in);
            System.out.println("-------------------");
            System.out.println("------ Login ------");
            System.out.println("Name: ");
            String name = scan.next();
            System.out.println("Password");
            String password = scan.next();

            Login l = new Login();
            ManagerDAO m = new ManagerDAO();

            if (l.verifyloginUser(name, password, m.returnEmployee())) {
                LPCRUD.consoleState = EnumConsoleStates.HOMEMENU.getEstadoMaquina();
                return l.getObj(name, password, m.returnEmployee());
            }
        }while (!Logado);
        return null;
    }
    
    public void verifyFirstUser(List<Employee> list) {
        if (list.isEmpty()) {
            ManagerDAO mDAO = new ManagerDAO();
            mDAO.Create(new Manager(1, "adm", "adm"));
        }
    }
}
