package lpcrud.consolestate;

import DAO.ManagerDAO;
import People.Employee;
import People.Manager;
import java.util.Scanner;
import lpcrud.LPCRUD;

public class ConsoleStateCreateMenuManager extends ConsoleState{

    @Override
    public boolean Execute(Employee e) {
        System.out.println("----------------------------------");
        System.out.println("------ Manager Creating Menu -----");    
        System.out.println("1 - Product");  
        System.out.println("2 - Order");
        System.out.println("3 - Client");
        System.out.println("4 - Manager");
        System.out.println("5 - Vendor");
        System.out.println("0 - Back to Home Menu"); 
         
        Scanner scan = new Scanner(System.in);     
        int opcao = scan.nextInt();
        
        
        switch (opcao){
            case 0:
                LPCRUD.consoleState = EnumConsoleStates.HOMEMENU.getEstadoMaquina(); 
                break;
            case 1:    
                LPCRUD.consoleState = EnumConsoleStates.REGISTERPRODUCT.getEstadoMaquina();
                break;
            case 2:                  
                break;
            case 3:
                LPCRUD.consoleState = EnumConsoleStates.REGISTERCLIENT.getEstadoMaquina(); 
                break;
            case 4:
                LPCRUD.consoleState = EnumConsoleStates.REGISTERMANAGER.getEstadoMaquina();
                break;
            case 5:
                LPCRUD.consoleState = EnumConsoleStates.REGISTERVENDOR.getEstadoMaquina();
                break;
        }
        return false;
    }    
}