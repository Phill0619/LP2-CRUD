package lpcrud.consolestate;

import People.Employee;
import java.util.Scanner;
import lpcrud.LPCRUD;

public class ConsoleStateCreateMenuVendor  extends ConsoleState{

    @Override
    public boolean Execute(Employee e) {
        System.out.println("---------------------------------");
        System.out.println("------ Vendor Creating Menu -----");    
        System.out.println("1 - Product");  
        System.out.println("2 - Order");
        System.out.println("3 - Client");
        System.out.println("0 - Back to Home Menu");    
        Scanner scan = new Scanner(System.in);     
        int opcao = scan.nextInt();
        switch (opcao)
        {
            case 0:
                LPCRUD.consoleState = EnumConsoleStates.HOMEMENU.getEstadoMaquina();  
                break;
            case 1:
                LPCRUD.consoleState = EnumConsoleStates.REGISTERPRODUCT.getEstadoMaquina();
                break;
            case 2:                  
                LPCRUD.consoleState = EnumConsoleStates.REGISTERORDER.getEstadoMaquina();
                break;
            case 3:
                LPCRUD.consoleState = EnumConsoleStates.REGISTERCLIENT.getEstadoMaquina(); 
                break;
        }
        return false;
    }
}

