/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lpcrud.consolestate;

import DAO.ProductDAO;
import DAO.VendorDAO;
import People.Employee;
import Things.Product;
import java.util.Scanner;
import lpcrud.LPCRUD;

/**
 *
 * @author NIKON-IMPRESSORA
 */
public class ConsoleStateRegisterProduct extends ConsoleState {
    
    @Override
    public boolean Execute(Employee e) {
        
        Scanner scan = new Scanner(System.in);
        System.out.println("-----------------------------------");
        System.out.println("------ Registering a Product ------");  
        
        try{
            System.out.println("Id"); 
            int id = scan.nextInt();
            System.out.println("Name");
            String name = scan.next();
            System.out.println("Price");
            int price = scan.nextInt();
            
            Product p = new Product(id,name,price);
            ProductDAO prodDAO = new ProductDAO();
            prodDAO.Create(p);            
        }
        catch(Exception d){
            System.out.print(d.toString());
        }
        
        System.out.println("Product created!");        
        LPCRUD.consoleState = EnumConsoleStates.HOMEMENU.getEstadoMaquina();  
        return false;
    }
    
}