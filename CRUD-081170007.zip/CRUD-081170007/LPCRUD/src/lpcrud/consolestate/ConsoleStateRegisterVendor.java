/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lpcrud.consolestate;

import DAO.VendorDAO;
import People.Employee;
import People.Vendor;
import java.util.Scanner;
import lpcrud.LPCRUD;

/**
 *
 * @author NIKON-IMPRESSORA
 */
public class ConsoleStateRegisterVendor extends ConsoleState {
    
    @Override
    public boolean Execute(Employee e) {
        
        Scanner scan = new Scanner(System.in);
        System.out.println("-----------------------------------");
        System.out.println("------ Registering a  Vendor ------");  
        
        try{
            System.out.println("Id"); 
            int id = scan.nextInt();
            System.out.println("Name");
            String name = scan.next();
            System.out.println("Password");
            String password = scan.next();
            
            Vendor m = new Vendor(id,name,password);
            VendorDAO vendorDAO = new VendorDAO();
            vendorDAO.Create(m);            
        }
        catch(Exception d){
            System.out.print(d.toString());
        }
        
        System.out.println("Vendor registred!");        
        LPCRUD.consoleState = EnumConsoleStates.HOMEMENU.getEstadoMaquina();  
        return false;
    }
    
}
