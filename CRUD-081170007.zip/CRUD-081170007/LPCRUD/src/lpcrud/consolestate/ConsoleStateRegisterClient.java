package lpcrud.consolestate;

import DAO.ClientDAO;
import People.Client;
import People.Employee;
import lpcrud.LPCRUD;
import java.util.Scanner;

public class ConsoleStateRegisterClient extends ConsoleState {
    
    @Override
    public boolean Execute(Employee e) {
        
        Scanner scan = new Scanner(System.in);
        System.out.println("----------------------------------");
        System.out.println("------ Registering a Client ------");  
        
        try{
            System.out.println("Id"); 
            int id = scan.nextInt();
            System.out.println("Name");
            String name = scan.next();        
            
            Client c = new Client(id,name);
            ClientDAO clientDAO = new ClientDAO();
            clientDAO.Create(c);            
        }
        catch(Exception exc){
            System.out.print(exc.toString());
        }
        
        System.out.println("Client created!");        
        LPCRUD.consoleState = EnumConsoleStates.HOMEMENU.getEstadoMaquina();  
        return false;
    }    
}
