/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lpcrud.consolestate;

import DAO.ClientDAO;
import DAO.ProductDAO;
import People.Client;
import People.Employee;
import Things.Thing;
import java.util.Scanner;
import lpcrud.LPCRUD;

/**
 *
 * @author NIKON-IMPRESSORA
 */
public class ConsoleStateReadMenuEmployee extends ConsoleState {

    @Override
    public boolean Execute(Employee e) {

        Scanner scan = new Scanner(System.in);
        System.out.println("----------------------------------");
        System.out.println("------ Reading Menu ------");
        System.out.println("1 - Products");
        System.out.println("2 - Orders");
        System.out.println("3 - Clients");
        System.out.println("4 - Employees");
        System.out.println("0 - Back to Home Menu");

        int opcao = scan.nextInt();
        switch (opcao) {
            case 0:
                LPCRUD.consoleState = EnumConsoleStates.HOMEMENU.getEstadoMaquina();
                break;
            case 1:
                try {
                    ProductDAO pDAO = new ProductDAO();
                    for(Thing th : pDAO.Read()){
                        System.out.println(th.toString());
                    }                    
                    LPCRUD.consoleState = EnumConsoleStates.HOMEMENU.getEstadoMaquina();
                } catch (Exception exc) {
                    System.out.print(exc.toString());
                }
                break;
            case 2:
                break;
            case 3:
                LPCRUD.consoleState = EnumConsoleStates.REGISTERCLIENT.getEstadoMaquina();
                break;
        }
        return false;
    }

}
