/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lpcrud;

import People.Employee;
import lpcrud.consolestate.EnumConsoleStates;
import lpcrud.consolestate.ConsoleState;
import lpcrud.consolestate.ConsoleStateLogin;

public class LPCRUD {

    public static ConsoleState consoleState;

    public static void main(String[] args) {        
        ConsoleStateLogin teste = new ConsoleStateLogin();
        Employee e = teste.ExecuteLogin();

        consoleState = EnumConsoleStates.HOMEMENU.getEstadoMaquina();
        Boolean saida = false;
        while (!saida) {
            saida = consoleState.Execute(e);
        }
    }
}
